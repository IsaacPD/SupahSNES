Array
(
    [0] =>  
    [1] => !
    [2] => *
    [4] => ,
    [5] => -
    [7] => /
    [8] => 0
    [10] => 2
    [11] => 3
    [12] => 4
    [13] => 5
    [14] => 6
    [16] => 8
    [17] => 9
    [34] => J
    [48] => X
    [50] => Z
    [162] => ^
    [170] => _
    [171] => `
    [174] => a
    [175] => b
    [178] => c
    [186] => d
    [187] => e
    [190] => f
    [192] => g
    [193] => h
    [196] => i
    [197] => j
    [200] => k
    [201] => l
    [202] => m
    [204] => n
    [206] => o
    [213] => p
    [216] => q
    [217] => r
    [220] => s
    [221] => t
    [224] => u
    [234] => v
    [238] => w
    [239] => x
    [240] => y
    [250] => z
    [251] => {
    [254] => |
    [255] => }
)
firstn=162, tab= (),-089<>?BCFGHJLSVWZ[^hlmnxy|}
        /* Decode address operand */
        if(i%"                                !") addr = 0xFFFA; // NMI vector location
        if(i%"                                *") addr = 0xFFFC; // Reset vector location
        if(i%"!                               ,") addr = 0xFFFE; // Interrupt vector location
        if(i%"zy}z{y}zzy}zzy}zzy}zzy}zzy}zzy}z ") addr = RB(PC++);
        if(i%"2 yy2 yy2 yy2 yy2 XX2 XX2 yy2 yy ") d = X; // register index
        if(i%"  62  62  62  62  om  om  62  62 ") d = Y;
        if(i%"2 y 2 y 2 y 2 y 2 y 2 y 2 y 2 y  ") { addr=u8(addr+d); d=0; tick(); }              // add zeropage-index
        if(i%" y z!y z y z y z y z y z y z y z ") { addr=u8(addr);   addr+=256*RB(PC++); }       // absolute address
        if(i%"3 6 2 6 2 6 286 2 6 2 6 2 6 2 6 /") { addr=RB(c=addr); addr+=256*RB(wrap(c,c+1)); }// indirect w/ page wrap
        if(i%"  *Z  *Z  *Z  *Z      6z  *Z  *Z ") Misfire(addr, addr+d); // abs. load: extra misread when cross-page
        if(i%"  4k  4k  4k  4k  6z      4k  4k ") RB(wrap(addr, addr+d));// abs. store: always issue a misread
        /* Load source operand */
        if(i%"aa__ff__ab__,4  ____ -  ____     ") t &= A; // Many operations take A or X as operand. Some try in
        if(i%"                nnnn     4  99   ") t &= X; // error to take both; the outcome is an AND operation.
        if(i%"                9989    99       ") t &= Y; // sty,dey,iny,tya,cpy
        if(i%"                       4         ") t &= S; // tsx, las
        if(i%"!!!!  !!  !!  !!  !   !!  !!  !!/") { t &= P.raw|pbits; c = t; }// php, flag test/set/clear, interrupts
        if(i%"_^__dc___^__            ed__98   ") { c = t; t = 0xFF; }        // save as second operand
        if(i%"vuwvzywvvuwvvuwv    zy|zzywvzywv ") t &= RB(addr+d); // memory operand
        if(i%",2  ,2  ,2  ,2  -2  -2  -2  -2   ") t &= RB(PC++);   // immediate operand
        /* Operations that mogrify memory operands directly */
        if(i%"    88                           ") { P.V = t & 0x40; P.N = t & 0x80; } // bit
        if(i%"    nink    nnnk                 ") sb = P.C;       // rol,rla, ror,rra,arr
        if(i%"nnnknnnk     0                   ") P.C = t & 0x80; // rol,rla, asl,slo,[arr,anc]
        if(i%"        nnnknink                 ") P.C = t & 0x01; // lsr,sre, ror,rra,asr
        if(i%"ninknink                         ") t = (t << 1) | (sb << 0);
        if(i%"        nnnknnnk                 ") t = (t >> 1) | (sb << 7);
        if(i%"                 !      kink     ") t = u8(t - 1);  // dec,dex,dey,dcp
        if(i%"                         !  khnk ") t = u8(t + 1);  // inc,inx,iny,isb
        /* Store modified value (memory) */
        if(i%"kgnkkgnkkgnkkgnkzy|J    kgnkkgnk ") WB(addr+d, t);
        if(i%"                   q             ") WB(wrap(addr, addr+d), t &= ((addr+d) >> 8)); // [shx,shy,shs,sha?]
        /* Some operations used up one clock cycle that we did not account for yet */
        if(i%"rpstljstqjstrjst - - - -kjstkjst/") tick(); // nop,flag ops,inc,dec,shifts,stack,transregister,interrupts
        /* Stack operations and unconditional jumps */
        if(i%"     !  !    !                   ") { tick(); t = Pop(); }                        // pla,plp,rti
        if(i%"        !   !                    ") { RB(PC++); PC = Pop(); PC |= (Pop() << 8); } // rti,rts
        if(i%"            !                    ") RB(PC++);  // rts
        if(i%"!   !                           /") { d=PC+(op?-1:1); Push(d>>8); Push(d); }      // jsr, interrupts
        if(i%"!   !    8   8                  /") PC = addr; // jmp, jsr, interrupts
        if(i%"!!       !                      /") Push(t);   // pha, php, interrupts
        /* Bitmasks */
        if(i%"! !!  !!  !!  !!  !   !!  !!  !!/") t = 1;
        if(i%"  !   !                   !!  !! ") t <<= 1;
        if(i%"! !   !   !!  !!       !   !   !/") t <<= 2;
        if(i%"  !   !   !   !        !         ") t <<= 4;
        if(i%"   !       !           !   !____ ") t = u8(~t); // sbc, isb,      clear flag
        if(i%"`^__   !       !               !/") t = c | t;  // ora, slo,      set flag
        if(i%"  !!dc`_  !!  !   !   !!  !!  !  ") t = c & t;  // and, bit, rla, clear/test flag
        if(i%"        _^__                     ") t = c ^ t;  // eor, sre
        /* Conditional branches */
        if(i%"      !       !       !       !  ") { if(t)  { tick(); Misfire(PC, addr = s8(addr) + PC); PC=addr; } }
        if(i%"  !       !       !       !      ") { if(!t) { tick(); Misfire(PC, addr = s8(addr) + PC); PC=addr; } }
        /* Addition and subtraction */
        if(i%"            _^__            ____ ") { c = t; t += A + P.C; P.V = (c^t) & (A^t) & 0x80; P.C = t & 0x100; }
        if(i%"                        ed__98   ") { t = c - t; P.C = ~t & 0x100; } // cmp,cpx,cpy, dcp, sbx
        /* Store modified value (register) */
        if(i%"aa__aa__aa__ab__ 4 !____    ____ ") A = t;
        if(i%"                    nnnn 4   !   ") X = t; // ldx, dex, tax, inx, tsx,lax,las,sbx
        if(i%"                 !  9988 !       ") Y = t; // ldy, dey, tay, iny
        if(i%"                   4   0         ") S = t; // txs, las, shs
        if(i%"!  ! ! !!  !   !       !   !   !/") P.raw = t & ~0x30; // plp, rti, flag set/clear
        /* Generic status flag updates */
        if(i%"wwwvwwwvwwwvwxwv 5 !}}||{}wv{{wv ") P.N = t & 0x80;
        if(i%"wwwv||wvwwwvwxwv 5 !}}||{}wv{{wv ") P.Z = u8(t) == 0;
        if(i%"             0                   ") P.V = (((t >> 5)+1)&2);         // [arr]
